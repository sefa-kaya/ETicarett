﻿using ShoppingAPI.Entity.Poco;

namespace Shopping.Business.Abstract;

public interface ICategoryService:IGenericService<Category>
{
}